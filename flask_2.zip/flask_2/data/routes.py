from data import app
from flask import render_template, request
from data.models import Push_date
from sqlalchemy import delete


@app.route('/', methods=['GET', 'POST'])
def home_page():
    co = Push_date.query.filter_by(id=1).first()
    if request.form.get('action1'):
        co.c(1)
    elif request.form.get('action2'):
        co.c(2)
    elif request.form.get('action3'):
        co.c(0)
    else:
        ()
    return render_template('home.html', c=co.hour)


@app.route('/2', methods=['GET', 'POST'])
def page_2():
    times = Push_date.query.filter_by()
    co2 = Push_date.query.filter_by(id=1).first()
    if request.form.get('action4'):
        # co2.c(1)
        del_ = Push_date.delete().where(Push_date.c.id == 1)
        db.execute(del_)
    else:
        ()
    return render_template('2.html', times=times)