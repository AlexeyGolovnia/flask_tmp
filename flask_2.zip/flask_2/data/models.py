from data import db

class Push_date(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    hour = db.Column(db.Integer())
    minute = db.Column(db.Integer())
    second = db.Column(db.Integer())

    def c(self, c):
        if c > 0:
            self.hour += c
        else:
            self.hour = 0
        db.session.commit()
